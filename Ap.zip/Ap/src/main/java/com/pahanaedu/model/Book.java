package com.pahanaedu.model;

public class Book {
    private int bookId;
    private String title;
    private String category;
    private double price;
    private String image;

    public Book() {}

    public Book(int bookId, String title, String category, double price, String image) {
        this.bookId = bookId;
        this.title = title;
        this.category = category;
        this.price = price;
        this.image = image;
    }

    // Getters & Setters
    public int getBookId() { return bookId; }
    public void setBookId(int bookId) { this.bookId = bookId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public String getImage() { return image; }
    public void setImage(String image) { this.image = image; }
}
