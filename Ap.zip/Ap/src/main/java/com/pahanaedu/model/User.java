package com.pahanaedu.model;

public class User implements Cloneable {
    private int userId;
    private String username;
    private String password;
    private String name;
    private String email;
    private String contactNo;
    private String address;

    // Private constructor for Builder
    private User(UserBuilder builder) {
        this.userId = builder.userId;
        this.username = builder.username;
        this.password = builder.password;
        this.name = builder.name;
        this.email = builder.email;
        this.contactNo = builder.contactNo;
        this.address = builder.address;
    }

    // Builder class
    public static class UserBuilder {
        private int userId; // ✅ added userId
        private String username;
        private String password;
        private String name;
        private String email;
        private String contactNo;
        private String address;

        // Builder setters
        public UserBuilder userId(int userId) { this.userId = userId; return this; }
        public UserBuilder username(String username) { this.username = username; return this; }
        public UserBuilder password(String password) { this.password = password; return this; }
        public UserBuilder name(String name) { this.name = name; return this; }
        public UserBuilder email(String email) { this.email = email; return this; }
        public UserBuilder contactNo(String contactNo) { this.contactNo = contactNo; return this; }
        public UserBuilder address(String address) { this.address = address; return this; }

        // Build method
        public User build() { return new User(this); }
    }

    // Clone method
    @Override
    public User clone() {
        try {
            return (User) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException(e);
        }
    }

    // Getters
    public int getUserId() { return userId; } // ✅ added getter
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getContactNo() { return contactNo; }
    public String getAddress() { return address; }
}
