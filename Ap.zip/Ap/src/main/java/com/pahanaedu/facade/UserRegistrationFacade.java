package com.pahanaedu.facade;

import com.pahanaedu.dao.UserDAO;
import com.pahanaedu.model.User;

public class UserRegistrationFacade {
    private final UserDAO userDAO;

    public UserRegistrationFacade() {
        this.userDAO = new UserDAO();
    }

    public boolean register(User user) {
        return userDAO.saveUser(user);
    }
}
