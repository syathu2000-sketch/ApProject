package com.pahanaedu.dao;

import com.pahanaedu.util.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class InvoiceDAO {

    // ✅ Get total invoice count
    public int getInvoiceCount() {
        String sql = "SELECT COUNT(*) FROM InvoiceUsers";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1); // return the count
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}
