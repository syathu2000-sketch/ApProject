package com.pahanaedu.dao;

import com.pahanaedu.model.User;
import com.pahanaedu.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDAO {

    // Registration: Save new user
    public boolean saveUser(User user) {
        String sql = "INSERT INTO Users (username, password, name, email, contactNo, address) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getInstance().getConnection();
             PreparedStatement ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getName());
            ps.setString(4, user.getEmail());
            ps.setString(5, user.getContactNo());
            ps.setString(6, user.getAddress());

            int affectedRows = ps.executeUpdate();
            if (affectedRows > 0) {
                // Retrieve the auto-generated userId
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        user = new User.UserBuilder()
                                .userId(rs.getInt(1)) // set the generated userId
                                .username(user.getUsername())
                                .password(user.getPassword())
                                .name(user.getName())
                                .email(user.getEmail())
                                .contactNo(user.getContactNo())
                                .address(user.getAddress())
                                .build();
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            System.out.println("Error saving user: " + e.getMessage());
        }
        return false;
    }

    // Login: Authenticate user
    public User login(String username, String password) {
        String sql = "SELECT * FROM Users WHERE username=? AND password=?";
        try (Connection con = DBConnection.getInstance().getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new User.UserBuilder()
                            .userId(rs.getInt("userId")) // ✅ include userId
                            .username(rs.getString("username"))
                            .password(rs.getString("password"))
                            .name(rs.getString("name"))
                            .email(rs.getString("email"))
                            .contactNo(rs.getString("contactNo"))
                            .address(rs.getString("address"))
                            .build();
                }
            }

        } catch (SQLException e) {
            System.out.println("Error during login: " + e.getMessage());
        }
        return null;
    }
}
