package com.pahanaedu.dao;

import com.pahanaedu.model.ContactMessage;
import com.pahanaedu.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ContactMessageDAO {

    public boolean saveMessage(ContactMessage msg) {
        String sql = "INSERT INTO ContactMessages (name, email, subject, message) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, msg.getName());
            ps.setString(2, msg.getEmail());
            ps.setString(3, msg.getSubject());
            ps.setString(4, msg.getMessage());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }


    public int getMessageCount() {
        String sql = "SELECT COUNT(*) FROM ContactMessages";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1); // first column = count
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}
