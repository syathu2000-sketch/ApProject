package com.pahanaedu.controller;

import com.pahanaedu.dao.BookDAO;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/DeleteBookServlet")
public class DeleteBookServlet extends HttpServlet {

    private BookDAO bookDAO;

    @Override
    public void init() {
        bookDAO = new BookDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int bookId = Integer.parseInt(request.getParameter("bookId"));

        boolean isDeleted = bookDAO.deleteBook(bookId);

        if (isDeleted) {
            response.sendRedirect("adminDashboard.jsp?deleteSuccess=true");
        } else {
            response.sendRedirect("adminDashboard.jsp?deleteError=true");
        }
    }
}
