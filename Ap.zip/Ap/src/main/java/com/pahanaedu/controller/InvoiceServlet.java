package com.pahanaedu.controller;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import com.pahanaedu.util.DBConnection;

@WebServlet("/invoice")
public class InvoiceServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");

        if(username == null){
            response.getWriter().println("<p>Please login to view the invoice.</p>");
            return;
        }

        String bookIdParam = request.getParameter("bookId");
        double totalAmount = 0.0;
        double discount = 0.0;

        List<Map<String,Object>> items = new ArrayList<>();

        try(Connection con = DBConnection.getInstance().getConnection()){

            PreparedStatement ps = con.prepareStatement("SELECT bookId, title, price FROM Books WHERE bookId = ?");
            ps.setInt(1, Integer.parseInt(bookIdParam));
            ResultSet rs = ps.executeQuery();

            if(rs.next()){
                Map<String,Object> item = new HashMap<>();
                item.put("bookId", rs.getInt("bookId"));
                item.put("title", rs.getString("title"));
                item.put("price", rs.getDouble("price"));
                item.put("quantity", 1);
                item.put("total", rs.getDouble("price"));
                totalAmount = rs.getDouble("price");
                items.add(item);
            }

            if(totalAmount >= 10000) discount = totalAmount * 0.05;
            double finalAmount = totalAmount - discount;

            // Save invoice to database
            String insertInvoice = "INSERT INTO InvoiceUsers(username, bookId, quantity, subtotal, discount, totalAmount, invoiceDate) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement insertPs = con.prepareStatement(insertInvoice);
            for(Map<String,Object> item: items){
                insertPs.setString(1, username);
                insertPs.setInt(2, (Integer)item.get("bookId"));
                insertPs.setInt(3, (Integer)item.get("quantity"));
                insertPs.setDouble(4, (Double)item.get("price"));
                insertPs.setDouble(5, discount);
                insertPs.setDouble(6, finalAmount);
                insertPs.setTimestamp(7, new Timestamp(System.currentTimeMillis()));
                insertPs.executeUpdate();
            }

            request.setAttribute("items", items);
            request.setAttribute("totalAmount", totalAmount);
            request.setAttribute("discount", discount);
            request.setAttribute("finalAmount", finalAmount);

            request.getRequestDispatcher("/components/invoice.jsp").forward(request, response);

        } catch(Exception e){
            e.printStackTrace();
        }
    }
}
