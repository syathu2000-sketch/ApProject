package com.pahanaedu.controller;

import com.pahanaedu.factory.UserFactory;
import com.pahanaedu.facade.UserRegistrationFacade;
import com.pahanaedu.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

    private UserRegistrationFacade registrationFacade;

    @Override
    public void init() {
        registrationFacade = new UserRegistrationFacade();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        User user = UserFactory.createUser(request);
        boolean isRegistered = registrationFacade.register(user);

        if (isRegistered) {
            response.sendRedirect("login.jsp?success=true");
        } else {
            response.sendRedirect("register.jsp?error=true");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("register.jsp");
    }
}
