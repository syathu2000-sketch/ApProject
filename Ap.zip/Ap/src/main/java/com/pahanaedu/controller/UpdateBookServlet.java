package com.pahanaedu.controller;

import com.pahanaedu.dao.BookDAO;
import com.pahanaedu.model.Book;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/UpdateBookServlet")
public class UpdateBookServlet extends HttpServlet {

    private BookDAO bookDAO;

    @Override
    public void init() {
        bookDAO = new BookDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int bookId = Integer.parseInt(request.getParameter("bookId"));
        String title = request.getParameter("title");
        String category = request.getParameter("category");
        double price = Double.parseDouble(request.getParameter("price"));
        String image = request.getParameter("image");

        Book book = new Book();
        book.setBookId(bookId);
        book.setTitle(title);
        book.setCategory(category);
        book.setPrice(price);
        book.setImage(image);

        boolean isUpdated = bookDAO.updateBook(book);

        if (isUpdated) {
            response.sendRedirect("adminDashboard.jsp?updateSuccess=true");
        } else {
            response.sendRedirect("adminDashboard.jsp?updateError=true");
        }
    }
}
