package com.pahanaedu.controller;

import com.pahanaedu.dao.ContactMessageDAO;
import com.pahanaedu.model.ContactMessage;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/sendContact")
public class SendContactServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String subject = req.getParameter("subject");
        String message = req.getParameter("message");

        ContactMessage msg = new ContactMessage();
        msg.setName(name);
        msg.setEmail(email);
        msg.setSubject(subject);
        msg.setMessage(message);

        ContactMessageDAO dao = new ContactMessageDAO();
        boolean isSaved = dao.saveMessage(msg);

        if (isSaved) {
            req.setAttribute("successMessage", "✅ Your message has been sent successfully!");
        } else {
            req.setAttribute("errorMessage", "❌ Failed to send your message. Try again later.");
        }

        req.getRequestDispatcher("contact.jsp").forward(req, resp);
    }
}
