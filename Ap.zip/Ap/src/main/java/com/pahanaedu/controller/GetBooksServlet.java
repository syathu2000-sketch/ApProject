package com.pahanaedu.controller;

import com.pahanaedu.dao.BookDAO;
import com.pahanaedu.model.Book;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/GetBooksServlet")
public class GetBooksServlet extends HttpServlet {

    private BookDAO bookDAO;

    @Override
    public void init() {
        bookDAO = new BookDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Book> bookList = bookDAO.getAllBooks();

        request.setAttribute("books", bookList);
        request.getRequestDispatcher("books.jsp").forward(request, response);
    }
}
