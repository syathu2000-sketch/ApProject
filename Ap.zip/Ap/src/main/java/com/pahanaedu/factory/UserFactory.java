package com.pahanaedu.factory;

import com.pahanaedu.model.User;
import javax.servlet.http.HttpServletRequest;

public class UserFactory {
    public static User createUser(HttpServletRequest request) {
        return new User.UserBuilder()
                .username(request.getParameter("username"))
                .password(request.getParameter("password"))
                .name(request.getParameter("name"))
                .email(request.getParameter("email"))
                .contactNo(request.getParameter("contactNo"))
                .address(request.getParameter("address"))
                .build();
    }
}
